<?php

if($_POST){
  //print_r($_POST);
$ename=$_POST['ename'];
$calorie=$_POST['calorie'];

$data1 = array("ename" => "$ename", 
              "calorie" => "$calorie");
                                                                  
$data_string = json_encode($data1);                                                                                   
                                                                                                                     
$c = curl_init('http://localhost:9000/addexercise');                                                                      
curl_setopt($c, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($c, CURLOPT_POSTFIELDS, $data_string);                                                                  
curl_setopt($c, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($c, CURLOPT_HTTPHEADER, array(                                                                          
    'Content-Type: application/json',                                                                                
    'Content-Length: ' . strlen($data_string))                                                                       
);                                                                                                                   


//execute post
$result = curl_exec($c);

//close connection
curl_close($c);

//echo $result;                                                                                                                   

}
?>
<?php include 'sidebar.php'?>


      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item"><a href="workout.html">Exercise</a></li>
            <li class="breadcrumb-item active">Add Exercise</li>

          </ol>


          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fa fa-cutlery"></i>
              Add Exercise</div>
            <div class="card-body">
              <div class="table-responsive">

<form method="POST">
  <div class="form-group">

      <label for="inputCategory4">Exercise Name</label>
      <input type="text" class="form-control" name="ename" placeholder="Exercise Name">
  </div>

  <div class="form-group">
    <label for="inputName">Calorie</label>
    <input type="text" class="form-control" name="calorie" placeholder="Calorie">
  </div>
  <button type="submit" class="btn btn-primary">Add Exercise</button>
</form>



              </div>
            </div>

          </div>

          <!-- <p class="small text-center text-muted my-5"> -->
            <!-- <em>More table examples coming soon...</em> -->
          <!-- </p> -->

        </div>
        <!-- /.container-fluid -->
<?php include 'footer.php';?>
