<?php
session_start();
unset($_SESSION["login_user"]);

session_destroy();
print_r($_SESSION);
header('location:login.php');
?>