<?php
set_time_limit(0);


  
function get_data($url)
{
$ch = curl_init();
//$timeout = 500;
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
//curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
$data = curl_exec($ch);
curl_close($ch);
return $data;
}
if($_POST){
// Insert
$fn=$_POST['name'];
$data1 = array(
                "fname" => $fn, 
                "fats" => $_POST['fat'],
                "carbohydrate" => $_POST['carbohydrate'],
                "protein" => $_POST['protein'],
                "calorie" => $_POST['calorie'],
                "saturatedfat" => $_POST['sfat'],
                "polyunsaturatedfat" => $_POST['pfat'],
                "monounsaturatedfat" => $_POST['mfat'],
                "transfat" => $_POST['tfat'],
                "cholestrol" => $_POST['cholestrol'],                                                                  
                "sodium" => $_POST['sodium'],
                "potassium" => $_POST['potassium'],
                "fibers" => $_POST['fiber'],
                "sugar" => $_POST['sugar'],
                "vitaminA" => $_POST['vitA'],
                "vitaminC" => $_POST['vitC'],
                "calcium" => $_POST['calcium'],
                "iron"=>$_POST['iron']
              );  
$data_string = json_encode($data1);                                                                                   
                                                                                                                     
$c = curl_init('http://localhost:9009/addfood');                                                                      
curl_setopt($c, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($c, CURLOPT_POSTFIELDS, $data_string);                                                                  
curl_setopt($c, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($c, CURLOPT_HTTPHEADER, array(                                                                          
    'Content-Type: application/json',                                                                                
    'Content-Length: ' . strlen($data_string))                                                                       
);                                                                                                                   
                                                                                                                     
$result = curl_exec($c);
}
?>
<?php include 'sidebar.php';?>


      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item"><a href="food.html">Food</a></li>
            <li class="breadcrumb-item active">Add Food</li>

          </ol>


          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fa fa-cutlery"></i>
              Add Food item</div>
            <div class="card-body">
              <div class="table-responsive">

                <form method="post">

  <div class="form-row">
 <!--   <div class="form-group col-md-6">
      <label for="inputCategory4">Category</label>
      <select id="inputCategory" name="select" class="form-control">
      <option selected>Choose...</option>"
 <?php     $url="http://localhost:9000/category/";
  
      $someArray =    json_decode(get_data($url), true);
      $temp=null; // Replace ... with your PHP Array
     foreach ($someArray as $key => $value) {
      echo $value["cid"] . ", " . $value["cname"] . "<br>";
     
       echo  "<option value=".$value["cid"].">".$value["cname"]."</option>";
     }
?>
      </select>
    </div>-->
  </div>

  <div class="form-group">
    <label for="inputName">Name</label>
    <input type="text" class="form-control" id="inputFoodName" placeholder="food" name="name">
  </div>

  <div class="form-row">
    <div class="form-group col-md-2">
      <label for="inputCity">Fat</label>
      <input type="text" class="form-control" id="inputCity" name="fat">
    </div>
    <div class="form-group col-md-2">
      <label for="inputState">Carbohydrate</label>
      <input type="text" class="form-control" id="inputCity" name="carbohydrate">
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">Protein</label>
      <input type="text" class="form-control" id="inputZip" name="protein">
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">Calorie</label>
      <input type="text" class="form-control" id="inputZip" name="calorie">
    </div>
     <div class="form-group col-md-2">
      <label for="inputZip">Vitamin A</label>
      <input type="text" class="form-control" id="inputZip" name="vitA">
    </div>
     <div class="form-group col-md-2">
      <label for="inputZip">Vitamin C</label>
      <input type="text" class="form-control" id="inputZip" name="vitC"> 
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-3">
      <label for="inputCity">Saturated fat</label>
      <input type="text" class="form-control" id="inputCity" name="sfat">
    </div>
    <div class="form-group col-md-3">
      <label for="inputState">Polyunsaturated fat</label>
      <input type="text" class="form-control" id="inputCity" name="pfat">
    </div>
    <div class="form-group col-md-3">
      <label for="inputZip">Monounsaturated fat</label>
      <input type="text" class="form-control" id="inputZip" name="mfat">
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">Trans fat</label>
      <input type="text" class="form-control" id="inputZip" name="tfat">
    </div>
     <div class="form-group col-md-1">
      <label for="inputZip">Iron</label>
      <input type="text" class="form-control" id="inputZip" name="iron">
    </div>
  </div>

    <div class="form-row">
    <div class="form-group col-md-2">
      <label for="inputCity">Cholestrol</label>
      <input type="text" class="form-control" id="inputCity" name="cholestrol">
    </div>
    <div class="form-group col-md-2">
      <label for="inputState">Sodium</label>
      <input type="text" class="form-control" id="inputCity" name="sodium">
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">Potassium</label>
      <input type="text" class="form-control" id="inputZip" name="potassium">
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">Fibers</label>
      <input type="text" class="form-control" id="inputZip" name="fiber">
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">Sugar</label>
      <input type="text" class="form-control" id="inputZip" name="sugar">
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">Calcium</label>
      <input type="text" class="form-control" id="inputZip" name="calcium">
    </div>
  </div>



  <button type="submit" class="btn btn-primary">Add Food item</button>
</form>



              </div>
            </div>

          </div>

          <!-- <p class="small text-center text-muted my-5"> -->
            <!-- <em>More table examples coming soon...</em> -->
          <!-- </p> -->

        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <?php include 'footer.php'?>