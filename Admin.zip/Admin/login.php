<?php

if($_POST){
  
$data1 = array("email" => $_POST['email'], 
              "password" => $_POST['password']);
                                                                  
$data_string = json_encode($data1);                                                                                   
                                                                                                                     
$c = curl_init('http://localhost:9009/loginuser');                                                                      
curl_setopt($c, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($c, CURLOPT_POSTFIELDS, $data_string);                                                                  
curl_setopt($c, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($c, CURLOPT_HTTPHEADER, array(                                                                          
    'Content-Type: application/json',                                                                                
    'Content-Length: ' . strlen($data_string))                                                                       
);                                                                                                                   


//execute post
$result = curl_exec($c);
$data=json_decode($result,true);
$uname=$data["data"];
$role=$uname["role"];
echo $uname["uname"];

if($data["status"] )
{
  session_start();
 
  header('location:http://localhost/fitness/admin/index.php');
$_SESSION['login_user']= $uname["uname"];
  echo "<html></html>";  // - Tell the browser there the page is done
  flush();               // - Make sure all buffers are flushed
  ob_flush();            // - Make sure all buffers are flushed
  exit;

}
else{
  echo "<script type='text/javascript'>alert('Login Failed!')</script>";
}

//close connection
curl_close($c);

                                                                                                     
}
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">

  </head>

  <body class="bg-dark">

<div class="container">
  <div class="card card-login mx-auto mt-5">
    <div class="card-header">Login</div>
    <div class="card-body">
      <form method="POST"> 
        <div class="form-group">
          <div class="form-label-group">
            <input type="email" id="inputEmail" name="email" class="form-control" placeholder="Email address" required="required" autofocus="autofocus">
            <label for="inputEmail">Email address</label>
          </div>
        </div>
        <div class="form-group">
          <div class="form-label-group">
            <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required="required" ">
            <label for="inputPassword">Password</label>
          </div>
        </div>
        <button type="submit" class="btn btn-primary btn-block" style="text-align:center" >Login</button>

      </form>
      
    </div>
  </div>
</div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  </body>

</html>
