
<?php include 'sidebar.php';


?>
      <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Breakfast',     11],
          ['Lunch',      2],
          ['Dinner',  2]
        ]);

        var options = {
          title: 'Daily Activities'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Activities</a>
            </li>
            </ol>

          <!-- Icon Cards-->
          <div class="row">
            <div class="col-xl-5 col-sm-10 mb-7">
              <div class="card text-white bg-danger o-hidden h-102">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fa fa-coffee"></i>
                  </div>
                  <div class="mr-7">Food</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="food.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
            <div class="col-xl-5 col-sm-12 xl-7" style="height:110px;">
              <div class="card text-white bg-danger o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-chart-bar"></i>
                  </div>
                  <div class="mr-5">Exercise</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="workout.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div></div>
            <p></p>
            <p></p>
            <div class="row" >
              <div id="piechart" style="width: 600px; height: 500px;"></div>
            </div>




        <!-- /.container-fluid -->





        <!-- /.container-fluid -->
<?php include 'footer.php';?>
