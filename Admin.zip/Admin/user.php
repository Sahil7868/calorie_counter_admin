<?php
set_time_limit(0);

function get_data($url)
{
$ch = curl_init();
//$timeout = 500;
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
//curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
$data = curl_exec($ch);
curl_close($ch);
return $data;
}



?>
<?php
include 'sidebar.php';
?>




      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active">Users</li>
          </ol>


          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              User Data Table</div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Gender</th>
                      <th>Height</th>
                      <th>Weight</th>
                      <th>Budget</th>
                      
                      <th>BMI</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Gender</th>
                      <th>Height</th>
                      <th>Weight</th>
                      <th>Budget</th>
                      
                      <th>BMI</th>
                    </tr>
                  </tfoot>
                  <tbody>
                  <form method="GET">
<?php
 $url="http://localhost:9009/users/";
  
 $someArray = json_decode(get_data($url), true);
 $temp=null; // Replace ... with your PHP Array

                    foreach ($someArray as $key => $value) {
                   
   
                    echo "<tr>";
                    
                      echo "<td>".$value["uname"]."</td>";
                      echo "<td>".$value["email"]."</td>";
                      echo "<td>".$value["gender"]."</td>";
                      echo "<td>".$value["height"]."</td>";
                      echo "<td>".$value["weight"]."</td>";
                      echo "<td>".$value["budget"]."</td>";
                      echo "<td>".$value["bmi"]."</td>";
                    
                    echo "</tr>";
                     echo "</tr>";
                    }
                  
           ?>         
                    </form>
                    
                  </tbody>
                </table>
              </div>
            </div>

          </div>

          <!-- <p class="small text-center text-muted my-5"> -->
            <!-- <em>More table examples coming soon...</em> -->
          <!-- </p> -->

        </div>
        <!-- /.container-fluid -->

    <?php 
    include 'footer.php';
    ?>
