<!DOCTYPE html>
<?php
set_time_limit(0);


function get_data($url)
{
$ch = curl_init();
//$timeout = 500;
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
//curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
$data = curl_exec($ch);
curl_close($ch);
return $data;
}


 

if($_GET)
{
 // print_r($_POST);
  $eid=$_GET['eid'];
  //echo "hahha".$eid;
/// Delete
$url1="http://localhost:9000/deleteexercise/".$eid."";
$curl = curl_init($url1);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

// Make the REST call, returning the result
$response = curl_exec($curl);


}


?>
<?php include 'sidebar.php';?>
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active">Exercise</li>
          </ol>


          <div class="card mb-3">
            <a class="btn btn-primary btn-block" href="addexercise.php">Add Exercise</a>
          </div>
          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              Exercise Data Table</div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>

                      <th>Exercise name</th>
                      <th>Calorie</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Exercise name</th>
                      <th>Calorie</th>
                      <th></th>
                    </tr>
                  </tfoot>
                  <tbody>
                    <form method="GET">
                  <?php
 $url="http://localhost:9000/exercise";
  
 $someArray =    json_decode(get_data($url), true);
 $temp=null; // Replace ... with your PHP Array
                    foreach ($someArray as $key => $value) {
  
   
                    echo "<tr>";
                    
                      echo "<td>".$value["ename"]."</td>";
                      echo "<td>".$value["calorie"]."</td>";
                     echo  "<td><a href=workout.php?eid=".$value["eid"].">Delete</a></td>";
                    echo "</tr>"; echo "</tr>";
                    }
              
           ?>   
</form>

                  </tbody>
                </table>
              </div>
            </div>

          </div>

          <!-- <p class="small text-center text-muted my-5"> -->
            <!-- <em>More table examples coming soon...</em> -->
          <!-- </p> -->

        </div>
        <!-- /.container-fluid -->
<?php include 'footer.php';?>